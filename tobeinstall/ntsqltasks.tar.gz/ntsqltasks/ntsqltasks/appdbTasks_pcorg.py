# -*- coding: utf-8 -*-
#"""
#Created on Sat Jul 11 12:55:40 2020
#
#@author: thors
#"""


#   ************************************************************
#   ** Create 'ssAppData' Database Connection **
#   ************************************************************
def create_db_connection():
    import mysql.connector
    from mysql.connector.errors import Error
    
    try:
        connection = mysql.connector.connect(
            host = "208.109.60.84",
            user = "ssAppData_Admin",
            password = "UNLSpraySafely1*",
            database = "ntApp_Data_Org",
            )
        if connection.is_connected():    
            print(connection)
            #cursor = connection.cursor()
            #print(cursor)
            return connection
    except Error as e:
        print(e)

def close_db_connection(conn):
    import mysql.connector
    from mysql.connector.errors import Error
    
    if conn.is_connected():
        conn.close()
        
    conn = None

    return conn

#   ************************************************************
#   **** EXECUTE QUERY WITHIN MySQL DATABASE ****
#   * Description -  This procedure applies to any query within 
#                    this task file NOT requiring user information, 
#                    and applies to all spray-safely databases 
#                    designated within the query parameters.       
#   ************************************************************
def execute_Create_query(connection, sql_query):
    import mysql.connector
    from mysql.connector.errors import Error
    
    try:
        with connection.cursor(buffered=True) as cursor:
            cursor.execute(sql_query)
            connection.commit()
    except Error as e:
        print(e)




#   ************************************************************
#   **** EXECUTE QUERY WITHIN MySQL DATABASE ****
#   * Description -  This procedure applies to any query within 
#                    this task file requiring user information, 
#                    and applies to all spray-safely databases 
#                    designated within the query parameters.       
#   ************************************************************
def execute_Insert_query(connection, sql_query, vals):
    import mysql.connector
    from mysql.connector.errors import Error
    
    try:
        if connection:
            if vals:
                with connection.cursor() as cursor:
                    cursor.execute(sql_query,vals)
                    connection.commit()
                    
                return cursor.lastrowid
                cursor.close()
                connection.close()
            else:
                return "no info"
        else:
            return "failed connection"
    except Error as e:
        print (e)
 
 


#   ************************************************************
#   **** EXECUTE QUERY WITHIN MySQL DATABASE ****
#   * Description -  This procedure applies to any query within 
#                    this task file requiring user information, 
#                    and applies to all spray-safely databases 
#                    designated within the query parameters.       
#   ************************************************************
def execute_query(connection, sql_query):
    import mysql.connector
    from mysql.connector.errors import Error
    
    returnArr = []
    
    try:
        if connection:
            with connection.cursor() as cursor:
                cursor.execute(sql_query)
                records = cursor.fetchall()
                return records
            cursor.close()
            connection.close()
        else:
            return "failed connection"
    except Error as e:
        print (e)


#   ************************************************************
#   ** Main App_Data EVENT DATABASE STRUCTURE **
#   ************************************************************

#   ************************************************************
#   * Create Main Table *
#   ************************************************************
def create_AppInfo_tbl():
    create_AppInfo_tbl_query = """CREATE TABLE IF NOT EXISTS 
                                        App_Info(
                                            ID INT NOT NULL,
                                            Org_ID INT NOT NULL,
                                            Farm_ID text NOT NULL,
                                            Field_ID text NOT NULL,
                                            Applicator_ID INT NOT NULL,
                                            TankMix text NOT NULL,
                                            App_Type text NOT NULL,
                                            Start_Time text NOT NULL,
                                            End_Time text NOT NULL,
                                            REI_Exp text NOT NULL,
                                            Equipment_Name text NOT NULL,
                                            Weather text NOT NULL,
                                            JD_Application_ID text NOT NULL,
                                            JD_OrgID text NOT NULL,
                                            Geometry text NOT NULL,
                                            PRIMARY KEY (ID),
                                            FOREIGN KEY (Applicator_ID) 
                                                REFERENCES Applicator_Info (Applicator_ID)
                                         )"""
    return create_AppInfo_tbl_query

#   ************************************************************    
#   * Create Relational Tables *
#   ************************************************************
def create_ApplicatorInfo_tbl():
    create_Applicator_Info_table_query = """CREATE TABLE IF NOT EXISTS 
                                                Applicator_Info(
                                                    Applicator_ID INT NOT NULL,
                                                    First_Name text NOT NULL,
                                                    Last_Name text NOT NULL,
                                                    License_Type text NOT NULL,
                                                    License_Num text NOT NULL,
                                                    Licensed_Cat text NOT NULL,
                                                    License_Exp text NOT NULL,
                                                    PRIMARY KEY (Applicator_ID)
                                                )"""
    return create_Applicator_Info_table_query

def create_InstructorInfo_tbl():
    create_Instructor_Info_table_query = """CREATE TABLE IF NOT EXISTS 
                                                Instructor_Info(
                                                    Instructor_ID INT NOT NULL,
                                                    First_Name text NOT NULL,
                                                    Last_Name text NOT NULL,
                                                    Contact_Num text NOT NULL,
                                                    Address text NOT NULL,
                                                    Email text NOT NULL,
                                                    Cert_Date text NOT NULL,
                                                    Cert_Exp text NOT NULL,
                                                    PRIMARY KEY (Instructor_ID)
                                                )"""
    return create_Instructor_Info_table_query

            # NOTE: Owner_Info Table see 'Main Application Event Database 
            #       Structure' 
            # NOTE: User_Info Table see ' User Information Database Structure' 



#   ************************************************************
#   *** MANIPULATE DATABASE TABLE DATA ***
#   * Description - 
#   ************************************************************

        
#   ************************************************************
#   ** Insert Table Information **
#   ************************************************************
def insert_Application():
    
    insert_Application_query = """INSERT INTO 
                                    App_Info(
                                        Org_ID,
                                        Farm_ID,
                                        Field_ID,
                                        Applicator_ID,
                                        TankMix,
                                        App_Type,
                                        Start_Time,
                                        End_Time,
                                        REI_Exp,
                                        Equipment_Name,
                                        Weather,
                                        JD_Application_ID,
                                        JD_OrgID,
                                        Geometry
                                    )
                                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    return insert_Application_query

def insert_Applicator():
    insert_Applicator_query = """INSERT INTO
                                    Applicator_Info(
                                        Applicator_ID,
                                        First_Name,
                                        Last_Name,
                                        License_Type,
                                        License_Num,
                                        Licensed_Cat,
                                        License_Exp
                                    )
                                    VALUES (%s,%s,%s,%s,%s,%s,%s)"""
    return insert_Applicator_query

def insert_Instructor():
    insert_Instructor_query = """ INSERT INTO
                                    Instructor_Info(
                                        Instructor_ID INT NOT NULL,
                                        First_Name text NOT NULL,
                                        Last_Name text NOT NULL,
                                        Contact_Num text NOT NULL,
                                        Address text NOT NULL,
                                        Email text NOT NULL,
                                        Cert_Date NOT NULL,
                                        Cert_Exp NOT NULL
                                    )
                                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""
    return insert_Instructor_query
    
#   ************************************************************    
#   ** Update Table Information **
#   ************************************************************

#Application -
    #Farm ID
def update_App_FarmID(farmID,appID):
    update_App_FarmID_post = "UPDATE App_Info SET `Farm_ID`='" + farmID + "' WHERE `App_ID`='" + appID + "'"
    return update_App_FarmID_post
    #Field ID
def update_App_FieldID(fieldID,appID):
    update_App_FieldID_post = "UPDATE App_Info SET `Field_ID`='" + fieldID + "' WHERE `App_ID`='" + appID + "'"
    return update_App_FieldID_post
    #Applicator ID
def update_App_ApplicatorID(applicatorID,appID):
    update_App_ApplicatorID_post = "UPDATE App_Info SET `Applicator_ID`='" + applicatorID + "' WHERE `App_ID`='" + appID + "'"
    return update_App_ApplicatorID_post
    #Date
def update_App_Date(date,appID):
    update_App_Date_post = "UPDATE App_Info SET `Date`='" + date + "' WHERE `App_ID`='" + appID + "'"
    return update_App_Date_post
    #TankMix
def update_App_TankMix(tankmix,appID):
    update_App_TankMix_post = "UPDATE App_Info SET `TankMix`='" + tankmix + "' WHERE `App_ID`='" + appID + "'"
    return update_App_TankMix_post
    #App_Type
def update_App_AppType(appType,appID):
    update_App_AppType_post = "UPDATE App_Info SET `App_Type`='" + appType + "' WHERE `App_ID`='" + appID + "'"
    return update_App_AppType_post
    #Start_Time
def update_App_StartTime(startTime,appID):
    update_App_StartTime_post = "UPDATE App_Info SET `Start_Time`='" + startTime + "' WHERE `App_ID`='" + appID + "'"
    return update_App_StartTime_post
    #End Time
def update_App_EndTime(endTime,appID):
    update_App_EndTime_post = "UPDATE App_Info SET `End_Time`='" + endTime + "' WHERE `App_ID`='" + appID + "'"
    return update_App_EndTime_post
    #REI Expiration
def update_App_REIExp(reiExp,appID):
    update_App_REIExp_post = "UPDATE App_Info SET `REI_Exp`='" + reiExp + "' WHERE `App_ID`='" + appID + "'"
    return update_App_REIExp_post
    #Equipment Name
def update_App_EquipmentName(equipName,appID):
    update_App_EquipmentName_post = "UPDATE App_Info SET `Equipment_Name`='" + equipName + "' WHERE `App_ID`='" + appID + "'"
    return update_App_EquipmentName_post
    #Weather
def update_App_Weather(weather,appID):
    update_App_Weather_post = "UPDATE App_Info SET `Weather`='" + weather + "' WHERE `App_ID`='" + appID + "'"
    return update_App_Weather_post
    #JD Event ID
def update_App_JDEventID(jdEventID,appID):
    update_App_JDEventID_post = "UPDATE App_Info SET `JD_Event_ID`='" + jdEventID + "' WHERE `App_ID`='" + appID + "'"
    return update_App_JDEventID_post
    #JD App ID
def update_App_JDAppID(jdAppID,appID):
    update_App_JDAppID_post = "UPDATE App_Info SET `JD_App_ID`='" + jdAppID + "' WHERE `App_ID`='" + appID + "'"
    return update_App_JDAppID_post
    #Geometry
def update_App_Geometry(geometry,appID):
    update_App_Geometry_post = "UPDATE App_Info SET `Geometry`='" + geometry + "' WHERE `App_ID`='" + appID + "'"
    return update_App_Geometry_post  


#Applicator -
    #First_Name
def update_Appl_FirstName(firstName,applID):
    update_Appl_FirstName_post = "UPDATE Instructor_Info SET `First_Name`='" + firstName + "' WHERE `Applicator_ID`='" + applID + "'"
    return update_Appl_FirstName_post
    #Last_Name
def update_Appl_LastName(lastName,applID):
    update_Appl_LastName_post = "UPDATE Instructor_Info SET `Last_Name`='" + lastName + "' WHERE `Applicator_ID`='" + applID + "'"
    return update_Appl_LastName_post
    #License_Type
def update_Appl_LicType(licType,applID):
    update_Appl_LicType_post = "UPDATE Instructor_Info SET `License_Type`='" + licType + "' WHERE `Applicator_ID`='" + applID + "'"
    return update_Appl_LicType_post
    #Licensed_Categories
def update_Appl_LicCat(licCat,applID):
    update_Appl_LicCat_post = "UPDATE Instructor_Info SET `License_Cat`='" + licCat + "' WHERE `Applicator_ID`='" + applID + "'"
    return update_Appl_LicCat_post
    #License_Expiration
def update_Appl_LicExp(licExp,applID):
    update_Appl_LicExp_post = "UPDATE Instructor_Info SET `License_Exp`='" + licExp + "' WHERE `Applicator_ID`='" + applID + "'"
    return update_Appl_LicExp_post


#Instructor -
    #First_Name
def update_Instr_FirstName(firstName,instrID):
    update_Instr_FirstName_post = "UPDATE Instructor_Info SET `First_Name`='" + firstName + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_FirstName_post
    #Last_Name
def update_Instr_lastName(lastName,instrID):
    update_Instr_LastName_post = "UPDATE Instructor_Info SET `Last_Name`='" + LastName + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_LastName_post
    #Contact_Num
def update_Instr_ContactNum(contactNum,instrID):
    update_Instr_ContactNum_post = "UPDATE Instructor_Info SET `Contact_Num`='" + contactNum + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_ContactNum_post
    #Address
def update_Instr_Address(address,instrID):
    update_Instr_Address_post = "UPDATE Instructor_Info SET `Address`='" + address + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_Address_post
    #Email
def update_Instr_Email(email,instrID):
    update_Instr_Email_post = "UPDATE Instructor_Info SET `Email`='" + email + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_Email_post
    #Cert_Date
def update_Instr_CertDate(certDate,instrID):
    update_Instr_CertDate_post = "UPDATE Instructor_Info SET `Cert_Date`='" + certDate + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_CertDate_post
    #Cert_Exp
def update_Instr_CertExp(certExp,instrID):
    update_Instr_CertExp_post = "UPDATE Instructor_Info SET `Cert_Exp`='" + certExp + "' WHERE `Instructor_ID`='" + instrID + "'"
    return update_Instr_CertExp_post


#   ************************************************************
#   ** Delete Table Information **
#   ************************************************************

#Application
def delete_Application(appID):
    delete_App_post = "DELETE FROM App_Info WHERE `App_ID`='" + appID + "'"
    return delete_App_post
#Applicator
def delete_Applicator(applID):
    delete_Appl_post = "DELETE FROM App_Info WHERE `Applicator_ID`='" + applID + "'"
    return delete_Appl_post
#Instructor
def delete_Instructor(instrID):
    delete_Instr_post = "DELETE FROM App_Info WHERE `Instructor_ID`='" + instrID + "'"
    return delete_Instr_post


#   ************************************************************
#   ** Query Table Information **
#   ************************************************************

#       * Specific Information Sets
#Application -
    #ID by Org_ID
def select_AppID_byOrgID(orgID):
    select_AppID_byOrgID_query = "SELECT ID FROM App_Info WHERE `Org_ID`='" + orgID + "'"
    return select_AppID_byJDAppID_query
    #ID by JD_Event_ID
def select_AppID_byJDEventID(jdEventIDID):
    select_AppID_byJDEventID_query = "SELECT ID FROM App_Info WHERE `JD_Event_ID`='" + jdEventID + "'"
    return select_AppID_byJDEventID_query
    #ID by JD_App_ID
def select_AppID_byJDAppID(jdAppID):
    select_AppID_byJDAppID_query = "SELECT ID FROM App_Info WHERE `JD_Application_ID`='" + jdAppID + "'"
    return select_AppID_byJDAppID_query
def select_AppID_byOrgJDAppID(orgID,jdAppID):
    select_AppID_byOrgJDAppID_query = "SELECT ID FROM App_Info WHERE `Org_ID`='" + orgID + "' AND `JD_Application_ID`='" + jdAppID + "'"
    return select_AppID_byOrgJDAppID_query
    #Org ID
def select_AppOrgID(appID):
    select_AppOrgID_query = "SELECT Org_ID FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppOrgID_queryv
    #Farm ID
def select_AppFarmID(appID):
    select_AppFarmID_query = "SELECT Farm_ID FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppFarmID_query
    #Field ID
def select_AppFieldID(appID):
    select_AppFieldID_query = "SELECT Field_ID FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppFieldID_query
    #Date
def select_AppDate(appID):
    select_AppDate_query = "SELECT Date FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppDate_query
    #TankMix
def select_AppTankMix(appID):
    select_AppTankMix_query = "SELECT TankMix FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppTankMix_query
    #Application Type
def select_AppType(appID):
    select_AppType_query = "SELECT App_Type FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppType_query
    #Start Time
def select_AppStartTime(appID):
    select_AppStartTime_query = "SELECT Start_Time FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppStartTime_query
    #End Time
def select_AppEndTime(appID):
    select_AppEndTime_query = "SELECT End_Time FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppEndTime_query
    #REI Expiration
def select_AppREIExp(appID):
    select_AppREIExp_query = "SELECT REI_Exp FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppREIExp_query
    #Equipment Name
def select_AppEquipName(appID):
    select_AppEquipName_query = "SELECT Equipment_Name FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppEquipName_query
    #Weather
def select_AppWeather(appID):
    select_AppWeather_query = "SELECT Weather FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppWeather_query
    #JD Event ID
def select_AppJDEventID(appID):
    select_AppJDEventID_query = "SELECT JD_Event_ID FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppJDEventID_query    
    #JD App ID
def select_AppJDAppID(appID):
    select_AppJDAppID_query = "SELECT JD_App_ID FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppJDAppID_query
    #Geometry
def select_AppGeometry(appID):
    select_AppGeometry_query = "SELECT Geometry FROM App_Info WHERE `ID`='" + appID + "'"
    return select_AppGeometry_query

#Applicator -
    #Applicator ID by FirstName/LastName
def select_ApplID_byFirstLastName(firstName,lastName):
    select_ApplID_byFirstLastName_query = "SELECT Applicator_ID FROM Applicator_Info WHERE `First_Name`='" + firstName + "' AND `Last_Name`='" + lastName + "'"
    return select_ApplID_byFirstLastName_query    
    #Applicator ID by License Number
def select_ApplID_byLicNum(licNum):
    select_ApplID_byLicNum_query = "SELECT Applicator_ID FROM Applicator_Info WHERE `License_Num`='" + licNum + "'"
    return select_ApplID_byLicNum_query 
    #First Name
def select_ApplFirstName(applID):
    select_ApplFirstName_query = "SELECT First_Name FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_ApplFirstName_query
    #Last Name
def select_ApplLastName(applID):
    select_ApplLastName_query = "SELECT Last_Name FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_ApplLastName_query
    #License Type
def select_ApplLicType(applID):
    select_ApplLicType_query = "SELECT License_Type FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_ApplLicType_query
    #License Number
def select_ApplLicNum(applID):
    select_ApplLicNum_query = "SELECT License_Num FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    #License Categories
def select_ApplLicCat(applID):
    select_ApplLicCat_query = "SELECT License_Cat FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_ApplLicCat_query
    #License_Expiration
def select_ApplLicExp(applID):
    select_ApplLicExp_query = "SELECT License_Exp FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_ApplLicExp_query

    
#Instructor -
    #Instructor ID by FirstName/LastName
def select_InstrID_byFirstLastName(firstName,lastName):
    select_InstrID_byFirstLastName_query = "SELECT Instructor_ID FROM Instructor_Info WHERE `First_Name`='" + firstName + "' AND `Last_Name`='" + lastName + "'"
    return select_InstrID_byFirstLastName_query
    #Applicator ID by License Number
def select_InstrID_byEmail(email):
    select_InstrID_byEmail_query = "SELECT Instructor_ID FROM Instructor_Info WHERE `Email`='" + email + "'"
    return select_InstrID_byEmail_query
    #Contact Number
def select_InstrContactNum(instrID):
    select_InstrContactNum_query = "SELECT Contact_Num FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_InstrContactNum_query
    #Address
def select_InstrAddress(instrID):
    select_InstrAddress_query = "SELECT Address FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_InstrAddress_query
    #Email
def select_InstrEmail(instrID):
    select_InstrEmail_query = "SELECT Email FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_InstrEmail_query
    #Certification Date
def select_InstrCertDate(instrID):
    select_InstrCertDate_query = "SELECT Cert_Date FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_InstrCertDate_query
    #Certification Expiration
def select_InstrCertExp(instrID):
    select_InstrCertExp_query = "SELECT Cert_Exp FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_InstrCertExp_query


#       * Entire Information Sets
#Application
def select_App_byOrgID(orgID):
    select_App_byOrgID_query = "SELECT * FROM App_Info WHERE `Org_ID`='" + orgID + "'"
    return select_App_byOrgID_query

def select_App_byAppID(appID):
    select_App_byAppID_query = "SELECT * FROM App_Info WHERE `ID`='" + appID + "'"
    return select_App_byAppID_query

def select_App_byOrgJDAppID(jdAppID,orgID):
    select_App_byOrgJDAppID_query = "SELECT * FROM App_Info WHERE `Org_ID`='" + orgID + "' AND `JD_Application_ID`='" + jdAppID + "'"
    return select_App_byOrgJDAppID_query
    
def select_App_byFarmFieldID(farmID,fieldID):
    select_App_byFarmFieldID_query = "SELECT * FROM App_Info WHERE `Farm_ID`='" + farmID + "' AND `Field_ID`='" + fieldID + "'"
    return select_App_byFarmFieldID_query
    
def select_App_byFarmOrgID(farmID,orgID):
    select_App_byFarmOrgID_query = "SELECT * FROM App_Info WHERE `Org_ID`='" + orgID + "' AND `Farm_ID`='" + farmID +  "'"
    return select_App_byFarmOrgID_query

def select_App_byFieldOrgID(fieldID,orgID):
    select_App_byFieldOrgID_query = "SELECT * FROM App_Info WHERE `Org_ID`='" + orgID + "' AND `Field_ID`='" + fieldID + "'"
    return select_App_byFieldOrgID_query
    
def select_App_byFarmFieldOrgID(farmID,fieldID,orgID):
    select_App_byFarmFieldOrgID_query = "SELECT * FROM App_Info WHERE `Farm_ID`='" + farmID + "' AND `Field_ID`='" + fieldID + "' AND `Org_ID`='" + orgID + "'"
    return select_App_byFarmFieldOrgID_query
    
def select_App_byJDEventID(jdEventID):
    select_App_byJDEventID_query = "SELECT * FROM App_Info WHERE `JD_Event_ID`='" + jdEventID + "'"
    return select_App_byJDEventID_query

def select_App_byJDAppID(jdAppID):
    select_App_byJDAppID_query = "SELECT * FROM App_Info WHERE `JD_Application_ID`='" + jdAppID + "'"
    return select_App_byJDAppID_query
    
def select_App_byREIExp(reiExp):
    select_App_byREIExp_query = "SELECT * FROM App_Info WHERE `REI_Exp`.Date>='" + Convert(datetime,reiExp) + "'"
    return select_App_byREIExp_query

#Applicator
def select_Appl_byApplID(applID):
    select_Appl_byApplID_query = "SELECT * FROM Applicator_Info WHERE `Applicator_ID`='" + applID + "'"
    return select_Appl_byApplID_query

def select_Appl_byFirstLastName(firstName,lastName):
    select_Appl_byFirstLastName_query = "SELECT * FROM Applicator_Info WHERE `First_Name`='" + firstName + "' AND `Last_Name`='" + lastName + "'"
    return select_Appl_byFirstLastName_query

def select_Appl_byLicNum(licNum):
    select_Appl_byLicNum_query = "SELECT * FROM Applicator_Info WHERE `License_Num`='" + licNum + "'"
    return select_Appl_byLicNum_query

def select_Appl_byLicExp(licExp):
    select_Appl_byLicNum_query = "SELECT * FROM Applicator_Info WHERE `License_Exp`<='" + licExp + "'"
    return select_Appl_byLicNum_query
    
#Instructor
def select_Instr_byInstrID(instrID):
    select_Instr_byInstrID_query = "SELECT * FROM Instructor_Info WHERE `Instructor_ID`='" + instrID + "'"
    return select_Instr_byInstrID_query
    
def select_Instr_byEmail(email):
    select_Instr_byEmail_query = "SELECT * FROM Instructor_Info WHERE `Email`='" + email + "'"
    return select_Instr_byEmail_query
    
def select_Instr_byFirstLastName(firstName,lastName):
    select_Instr_byFirstLastName_query = "SELECT * FROM Instructor_Info WHERE `First_Name`='" + firstName + "' AND `Last_Name`='" + lastName + "'"
    return select_Instr_byFirstLastName_query    




